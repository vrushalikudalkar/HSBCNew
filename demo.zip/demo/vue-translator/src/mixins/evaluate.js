export default {
    methods: {
      getValue: function (a) {
          var b = a.replace(/^"(.*)"$/, '$1')
          console.log("mixin",b)
        return b;
      },
    }
}