<template>
  <div>
    <b-table striped hover :items="data" :fields="block.columns">
      <template v-for="(field,index) in block.columns" v-slot:[`cell(${field.key})`]="data">
          <template  v-if="field.type==='image'">
            <b-link :key="index" :href=data.value><img  :src="require(`@/assets/${field.image}.png`)" width="20px" /></b-link>
          </template>
           <template  v-else>
            <div :key="index">{{ data.value }}</div>
          </template>
      </template>
    </b-table>
  </div>
</template>

<script>
export default {
  name: "GridList",
  props: {
    block: Object,
    data: Array
  },
};
</script>

<style></style>
