<template>
  <div>
    <div v-for="(item, index) in block.components" :key="index">
      <template v-if="item.type === 'GridList'">
        <component
          :ref="item.name"
          :is="item.type"
          :key="index"
          :block="item.config"
          :data="dataList[item.config.dataSource]"
          v-bind:class="item.cssClasses"
        ></component>
      </template>
      <template v-if="item.type === 'Section'">
        <component  :ref="item.name" :is="item.type" :block="item" :dataList="dataList"></component>
        </template>
      <template v-if="item.type === 'header'">
        <component
          :ref="item.name"
          :is="item.config.tag"
          :key="index"
          v-bind:class="item.cssClasses"
        >
          {{ item.config.content }}</component
        >
      </template>
    </div>
  </div>
</template>

<script>
import GridList from '@/components/GridList.vue'
export default {
  name: "Section",
  props: {
    block: Object,
    dataList: Object
  },
  components: {
    GridList
  },
};
</script>

<style></style>
