<template>
  <div>
     
    <div v-for="(item, index) in myJson.components" :key="index">
      <template v-if="item.type === 'Section' && componentVisibility[item.name]">
        <component
          :ref="item.name"
          :is="item.type"
          :block="item"
          :dataList="dataSourceObject"
        ></component>
      </template>
      <template v-if="item.type === 'GridList' && componentVisibility[item.name]">
        <component
          :ref="item.name"
          :is="item.type"
          :key="index"
          :block="item.config"
          :data="dataSourceObject[item.config.dataSource]"
          v-bind:class="item.cssClasses"
          
        ></component>
      </template>
      <template v-if="item.type === 'header' && componentVisibility[item.name]">
        <component
          :ref="item.name"
          :is="item.config.tag"
          :key="index"
          v-bind:class="item.cssClasses"
        >
          {{ item.config.content }}</component
        >
      </template>
    </div>
    
  </div>
</template>

<script>
import GridList from "./components/GridList.vue";
import Section from "./components/Section.vue";
import evaluate from "./mixins/evaluate.js";
import json from "@/json/control-landing-page.json";
import services from "@/services/service";

var methods = {};
var functionArray = [];
var dataobj = {
  myJson: json,
  componentVisibility: {},
  dataSourceObject: {},
  abc: "oh wow"
};

json.dataSources.forEach((source) => {
  dataobj[source.name] = [];
});

json.components.forEach((source)=>{
  dataobj.componentVisibility[source.name]=false
})

let handlers = json.handlers;
handlers.forEach((element) => {
  if (element.type === "apicall") {

    functionArray.push({
      functionName: element.name,
      function: function() {
        let arr, pos;
        if (arguments && arguments.length == 2) {
          arr = arguments[0];
          pos = arguments[1];
        }

        let tokens = this.getInterpolationTokens(element.url);
        var url = '';
        if (tokens) {
          url = tokens.unchangedTokens[0];
          for(let i = 0; i < tokens.replaceTokens.length; i++) {
            url += this.interpolate(tokens.replaceTokens[i], arr, pos)
            url += tokens.unchangedTokens[i+1]
          }
        } else {
          url = element.url;
        }
        let payload = { URL: url };

        services.fetchData(payload).then((res) => {
          if (element.successDataSource) {
            this.updateDataSource(element.successDataSource, res, arr, pos);
          }

          if (element.onSuccess) {
            element.onSuccess.forEach((element) => {
            this[element]();
          });
        }
        })
        .catch(err=>{
          if (element.errorDataSource) {
            this.updateDataSource(element.errorDataSource, err, arr, pos);
          }
  
          if(element.onError){
            element.onError.forEach((value)=>{
              this[value]()
            })
          }
        });
      },
    });
  } else if (element.type === "view") {
    functionArray.push({
      functionName: element.name,
      function: function() {
        for(let val in this.componentVisibility )
        {
         (element.component  === val) ? this.componentVisibility[val]= true : this.componentVisibility[val] = false;
        }
      }
    });
  }
});
functionArray.forEach(function(item) {
  methods[item.functionName] = item.function;
});
console.log(methods);

methods.getInterpolationTokens = function(str) {
  const interpolationRE = /\{\{.+?\}\}/g
  if (!interpolationRE.test(str)) {
    return
  }

  let unchangedTokens = []
  let lastIndex = interpolationRE.lastIndex = 0
  let match, index
  let replaceTokens = []
  while((match = interpolationRE.exec(str))) {
    index = match.index
    replaceTokens.push(match[0].slice(2, match[0].length-2))
    if (index > lastIndex) {
      unchangedTokens.push(str.slice(lastIndex, index))
    }
    lastIndex = index + match[0].length
  }
  if (lastIndex < str.length) {
    unchangedTokens.push(str.slice(lastIndex))
  }
  return {
    replaceTokens, 
    unchangedTokens
  }
}

methods.interpolate = function(interpolateToken, arr, pos) {
  const dotPos = interpolateToken.indexOf('.')
  if (dotPos != -1) {
    const firstPart = interpolateToken.slice(0, dotPos)
    const secondPart = interpolateToken.slice(dotPos+1)
    if (firstPart.startsWith('$')) {
      const keyword = firstPart.slice(1)
      if (keyword === "element") {
        return arr[pos][secondPart]
      }
      return
    }else {
      // TODO: handle inner data sources
      return
    }
  }
  return this[interpolateToken]
}

methods.updateDataSource = function(dataSourceToken, val, arr, pos) {
  const dotPos = dataSourceToken.indexOf('.')
  if (dotPos != -1) {
    const firstPart = dataSourceToken.slice(0, dotPos)
    const secondPart = dataSourceToken.slice(dotPos+1)
    if (firstPart.startsWith('$')) {
      const keyword = firstPart.slice(1)
      if (keyword === "element") {
        this.$set(arr[pos], secondPart, val);
      }
    }else {
      // TODO: handle inner data sources
      return
    }
  } else {
    this.$set(this, dataSourceToken, val);
    this.$set(this.dataSourceObject, dataSourceToken, val);
  }
}

export default {
  name: "App",
  components: {
    GridList,
    Section,
  },
  mixins: [evaluate],
  data() {
    return dataobj;
      
  },
  methods: methods,
  created() {
    
    json.onLoad.forEach(async (element) => {
      this[element]();
    });

    json.dataSources.forEach((source) => {
      if (source.entityProcessor && source.entityProcessor.length != 0) {
        this.$watch(source.name, function(newVal, oldVal) {
          // weird check as watch is called with same data too!
          if (newVal != oldVal) {
            for (let i = 0; i < this[source.name].length; i++) {
              source.entityProcessor.forEach(processor => this[processor](this[source.name], i));
            }
          }
        });
      }
    });
  },
  mounted() {
    console.log("References: ",this.$refs);
  },
};
</script>

<style>
.headerClass {
  text-align: center;
  color: #122c02;
  margin-top: 60px;
  margin-bottom: 40px;
  font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
  
}
.subheader{
  text-align: center;
  color: rgb(116, 28, 70);
  margin-bottom: 40px;
  font-family: Georgia, 'Times New Roman', Times, serif;
  text-decoration: underline;
}
.grid-style{
  background-color: rgb(201, 232, 241);
  table-layout: fixed;
  font-family: unset;
  text-align: center;
  table-layout: fixed;
  margin: 50px;
  border-block-start: solid gray 1px
  
}

</style>
