const services = {
  fetchData: async (payload) => {
    let { URL } = payload;
    console.log(URL);
    // let response = await axios.get(URL));
    // return response.data;

    if (URL == "/domains") {
      await new Promise(resolve => setTimeout(function () { resolve() }, 500));
      return [
          { domain: "Procurement", bps_titles: ["Sourcing, Freight Management"], dashboard: "https://google.com" },
          { domain: "Logistics", bps_titles: ["Warehousing, Fulfillment, Inventory Management"], dashboard: "https://github.com" },
          { domain: "Retail", bps_titles: ["Markets Advisory, Digital Insurance"], dashboard: "https://bitbucket.com" },
          { domain: "Finance", bps_titles: ["Customer Experience Management, Business Consulting"], dashboard: "https://vuejs.org" }
      ];
    } else if (URL == "/domains/Procurement/cost") {
      await new Promise(resolve => setTimeout(function () { resolve() }, 2000));
      return 3020.6;
    } else if (URL == "/domains/Logistics/cost") {
      await new Promise(resolve => setTimeout(function () { resolve() }, 3000));
      return 4077.4;
    } else if (URL == "/domains/Retail/cost") {
      await new Promise(resolve => setTimeout(function () { resolve() }, 3500));
      return 5647.8;
    } else if (URL == "/domains/Finance/cost") {
      await new Promise(resolve => setTimeout(function () { resolve() }, 4500));
      return 8974.2;
    }
    throw new Error("dont know the URL!");
  }
};
export default services;
